from typing import ItemsView
from django.shortcuts import render, redirect
from django.contrib import messages
from .models import *
import bcrypt

def index(request):
    return render(request, "index.html")

def register(request):
    errors = User.objects.validate(request.POST)

    if len(errors):
        for key, value in errors.items():
            messages.error(request, value)
        return redirect('/')
    else:
        user = User.objects.create(
            first_name = request.POST['first_name'], 
            last_name = request.POST['last_name'],
            email = request.POST['email'],
            password = bcrypt.hashpw(request.POST['password'].encode(), bcrypt.gensalt()).decode()
        )
        request.session['user_id'] = user.id
        request.session['first_name'] = user.first_name
        request.session['last_name'] = user.last_name
        return redirect('/account')

def login(request):
    errors = User.objects.login_validate(request.POST)

    if len(errors):
        for key, value in errors.items():
            messages.error(request, value)
        return redirect('/')
    else:
        user = User.objects.get(email=request.POST['login_email'])
        request.session['user_id'] = user.id
        request.session['first_name'] = user.first_name
        request.session['last_name'] = user.last_name
        return redirect('/account')

def welcome(request):
    if 'user_id' not in request.session:
        return redirect('/')
    user = User.objects.get(id=request.session['user_id'])
    context = {
        'user': user
    } 
    return render(request, 'purchase.html', context)

def edit(request, id):
    errors = User.objects.edit_validate(request.POST)

    if len(errors):
        for key, value in errors.items():
            messages.error(request, value)
        return redirect('/account')
    edit_user = User.objects.get(id=id)
    edit_user.first_name = request.POST['first_name']
    edit_user.last_name = request.POST['last_name']
    edit_user.email = request.POST['email']
    edit_user.save()
    messages.success(request, "You have successfully updated your account information")
    return redirect('/account')

def account(request):
    if 'user_id' not in request.session:
        return redirect('login.html')
    context = {
        'user': User.objects.get(id=request.session['user_id'])
    }
    return render(request, 'account.html', context)

def purchase_item(request):
    if 'user.id' not in request.session:
        return render(request, 'purchase.html')
    context = {
        'purchase_item': Item.objects.create(
            item = request.POST['item'], 
            description = request.POST['description'], 
            price = request.POST['price'],
            quantity = request.POST['quantity'],
        )
    }
    return render(request,'thankyou.html', context)

def add_like(request, id):
    liked_item = Item.objects.get(id=id)
    user_liking = User.objects.get(id=request.session['user_id'])
    liked_item.user_likes.add(user_liking)
    return redirect('/orderhistory')

# def like(request, id):
#     item = User.objects.get(id=id)
#     item.like()
#     return render('orderhistory.html')

def orderhistory(request):
    return render(request, 'orderhistory.html')

def login_page(request):
    return render(request, 'login.html')


def delete(request, id):
    user = User.objects.get(id=id)
    if not user: 
        return render(request, 'account.html')
    user.delete()
    return redirect('/logout')
    

def logout(request):
    request.session.flush()
    return redirect('/')
















# Create your views here.
