from django.urls import path
from . import views 

urlpatterns = [
    path('', views.index), 
    path('register', views.register),
    path('login', views.login),
    path('login_page', views.login_page),
    path('purchase_item', views.purchase_item),
    path('add_like/<int:id>', views.add_like), 
    path('orderhistory', views.orderhistory),
    path('delete/<int:id>', views.delete),
    path('edit/<int:id>', views.edit),
    path('account', views.account),
    path('logout', views.logout),
]


